ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS carrier TEXT,
  ADD COLUMN IF NOT EXISTS tracking_number TEXT,
  ADD COLUMN IF NOT EXISTS eta_date DATE,
  ADD COLUMN IF NOT EXISTS shipped_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS out_for_delivery_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMPTZ;

CREATE TABLE IF NOT EXISTS public.order_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  message TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS order_events_order_id_idx ON public.order_events(order_id);

GRANT SELECT ON public.order_events TO authenticated;
GRANT ALL ON public.order_events TO service_role;
ALTER TABLE public.order_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view events for their own orders" ON public.order_events;
CREATE POLICY "Users can view events for their own orders"
ON public.order_events FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_events.order_id AND o.user_id = auth.uid()));

CREATE OR REPLACE FUNCTION public.log_order_status()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.order_events (order_id, status, message)
    VALUES (NEW.id, NEW.status, 'Order placed. We are confirming your payment and preparing your items.');
    RETURN NEW;
  END IF;

  IF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.order_events (order_id, status, message)
    VALUES (NEW.id, NEW.status, CASE NEW.status
      WHEN 'confirmed' THEN 'Order confirmed and being prepared.'
      WHEN 'packed' THEN 'Your order has been packed.'
      WHEN 'shipped' THEN 'Your order has been shipped.'
      WHEN 'out_for_delivery' THEN 'Your order is out for delivery today.'
      WHEN 'delivered' THEN 'Delivered. Thank you for shopping with EV.'
      WHEN 'cancelled' THEN 'Order cancelled.'
      ELSE 'Order updated.' END);

    IF NEW.status = 'shipped' AND NEW.shipped_at IS NULL THEN NEW.shipped_at = now(); END IF;
    IF NEW.status = 'out_for_delivery' AND NEW.out_for_delivery_at IS NULL THEN NEW.out_for_delivery_at = now(); END IF;
    IF NEW.status = 'delivered' AND NEW.delivered_at IS NULL THEN NEW.delivered_at = now(); END IF;
  END IF;

  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION public.log_order_status() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS orders_log_status_insert ON public.orders;
CREATE TRIGGER orders_log_status_insert AFTER INSERT ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.log_order_status();

DROP TRIGGER IF EXISTS orders_log_status_update ON public.orders;
CREATE TRIGGER orders_log_status_update BEFORE UPDATE ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.log_order_status();

UPDATE public.orders SET eta_date = COALESCE(eta_date, delivery_date) WHERE eta_date IS NULL;