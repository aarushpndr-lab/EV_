# EV Store — running it on your computer (VS Code)

## 1. Open and install

1. Unzip the project and open the folder in VS Code.
2. In the VS Code terminal run:

```bash
npm install     # or: bun install
```

## 2. Add your settings

```bash
cp .env.example .env    # Windows: copy .env.example .env
```

Open `.env` and fill in the values. The only ones needed to get the site
running with working login, orders and tracking are:

- `VITE_SUPABASE_URL` and `SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY` and `SUPABASE_PUBLISHABLE_KEY`
- `VITE_SUPABASE_PROJECT_ID` and `SUPABASE_PROJECT_ID`

You'll find them in your Lovable project under **Cloud → Settings (API)**.
Restart the dev server after any change to `.env`.

## 3. Start it

```bash
npm run dev     # or: bun run dev
```

Open the address it prints (usually http://localhost:8080).

## 4. What works with which setting

| Feature | Needs |
| --- | --- |
| Sign up / sign in (name, phone, address, email, password) | the Supabase values above |
| Stay signed in forever on that device | nothing extra |
| Cart, checkout, delivery date (1 week out minimum) | the Supabase values above |
| Order tracking timeline (placed → packed → shipped → delivered) | the Supabase values above |
| Admin control room (all orders, all customers, edit shipping) | be signed in as the owner account |
| EV Assistant Bot | `LOVABLE_API_KEY` |
| Order alert email to your Gmail | email service key + a verified sender domain |
| Card payments with real money | Razorpay (or Stripe) keys |

## 5. Google sign-in

Google sign-in is handled by Lovable and works on the published site and
preview. On `localhost` use email + password instead.

## 6. Order emails

Alerts go to **aarushpndr@gmail.com**. A Gmail address can only *receive*;
sending requires a domain you own (e.g. `evstore.in`) verified with the email
service. Until then, every order is still saved in full — customer name, phone,
full delivery address, items, total, payment method and delivery slot — and is
visible in the admin control room.

## 7. Real card payments

Card charging needs a payment account (Razorpay for India). Add the keys to
`.env` and the card option starts taking real money. Without them, customers
can still order using **Cash on delivery** or **Bank / UPI transfer**, and you
confirm the payment yourself from the admin control room.

## Useful commands

```bash
npm run dev      # start the local site
npm run build    # production build
npm run lint     # check the code
```
