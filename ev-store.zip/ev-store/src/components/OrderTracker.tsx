export const TRACKING_STEPS = [
  { key: "placed", label: "Order placed" },
  { key: "confirmed", label: "Confirmed" },
  { key: "packed", label: "Packed" },
  { key: "shipped", label: "Shipped" },
  { key: "out_for_delivery", label: "Out for delivery" },
  { key: "delivered", label: "Delivered" },
] as const;

export type TrackingEvent = {
  id: string;
  status: string;
  message: string;
  created_at: string;
};

export function statusLabel(status: string) {
  const step = TRACKING_STEPS.find((s) => s.key === status);
  return step?.label ?? status.replace(/_/g, " ");
}

function formatDate(value: string | null) {
  if (!value) return "—";
  return new Date(value.length <= 10 ? `${value}T00:00:00` : value).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function OrderTracker({
  status,
  etaDate,
  deliverySlot,
  carrier,
  trackingNumber,
  events,
}: {
  status: string;
  etaDate: string | null;
  deliverySlot: string | null;
  carrier: string | null;
  trackingNumber: string | null;
  events: TrackingEvent[];
}) {
  const cancelled = status === "cancelled";
  const currentIndex = TRACKING_STEPS.findIndex((s) => s.key === status);
  const activeIndex = cancelled ? -1 : currentIndex < 0 ? 0 : currentIndex;
  const progress = cancelled ? 0 : (activeIndex / (TRACKING_STEPS.length - 1)) * 100;

  return (
    <div className="mt-5 rounded-2xl border border-border bg-surface-2 p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm font-semibold">
          {cancelled ? "Order cancelled" : `Status: ${statusLabel(status)}`}
        </p>
        <p className="text-xs text-muted-foreground">
          {status === "delivered" ? "Delivered on " : "Arriving "}
          <span className="font-medium text-foreground">{formatDate(etaDate)}</span>
          {deliverySlot ? ` · ${deliverySlot}` : ""}
        </p>
      </div>

      {!cancelled && (
        <>
          <div className="relative mt-5 h-1 rounded-full bg-border">
            <div
              className="absolute inset-y-0 left-0 rounded-full gradient-fill transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>

          <ol className="mt-3 grid grid-cols-3 gap-2 text-[11px] sm:grid-cols-6">
            {TRACKING_STEPS.map((step, index) => (
              <li
                key={step.key}
                className={
                  index <= activeIndex ? "font-semibold text-foreground" : "text-muted-foreground-2"
                }
              >
                {step.label}
              </li>
            ))}
          </ol>
        </>
      )}

      {(carrier || trackingNumber) && (
        <p className="mt-4 text-xs text-muted-foreground">
          Courier: <span className="text-foreground">{carrier ?? "EV Logistics"}</span>
          {trackingNumber && (
            <>
              {" "}· Tracking ID <span className="font-mono text-foreground">{trackingNumber}</span>
            </>
          )}
        </p>
      )}

      {events.length > 0 && (
        <ul className="mt-4 space-y-3 border-t border-border pt-4">
          {events.map((event) => (
            <li key={event.id} className="flex gap-3 text-xs">
              <span className="mt-1 h-2 w-2 shrink-0 rounded-full gradient-fill" aria-hidden />
              <span>
                <span className="font-semibold text-foreground">{statusLabel(event.status)}</span>
                <span className="text-muted-foreground"> — {event.message}</span>
                <span className="block text-muted-foreground-2">
                  {new Date(event.created_at).toLocaleString("en-IN")}
                </span>
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
