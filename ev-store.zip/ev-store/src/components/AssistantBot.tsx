import { useEffect, useRef, useState } from "react";

type ChatMessage = { role: "user" | "assistant"; content: string };

const GREETING: ChatMessage = {
  role: "assistant",
  content:
    "Hi, I'm the EV Assistant Bot 👋 I can guide you through our products, payment options and delivery slots. What are you looking for?",
};

const SUGGESTIONS = [
  "What products do you have?",
  "How does payment work?",
  "When will my order arrive?",
];

export function AssistantBot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([GREETING]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  const send = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || busy) return;
    const next = [...messages, { role: "user" as const, content: trimmed }];
    setMessages(next);
    setInput("");
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ messages: next.filter((m) => m !== GREETING) }),
      });
      const data = (await res.json().catch(() => ({}))) as { reply?: string; error?: string };
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            data.reply ||
            data.error ||
            "Sorry, I couldn't answer that just now. Please try again in a moment.",
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Network hiccup — please try that again." },
      ]);
    } finally {
      setBusy(false);
      inputRef.current?.focus();
    }
  };

  return (
    <>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-5 right-5 z-[60] flex items-center gap-2 rounded-full px-5 py-3 text-sm font-semibold text-primary-foreground shadow-2xl gradient-fill"
        >
          <span className="h-2 w-2 rounded-full bg-primary-foreground" aria-hidden />
          EV Assistant Bot
        </button>
      )}

      {open && (
        <div className="fixed bottom-5 right-5 z-[60] flex h-[520px] w-[min(92vw,380px)] flex-col overflow-hidden rounded-2xl border border-border bg-background shadow-2xl">
          <div className="flex items-center justify-between border-b border-border bg-surface px-4 py-3">
            <div className="flex items-center gap-2">
              <span className="h-7 w-7 rounded-full gradient-fill" aria-hidden />
              <div>
                <p className="font-display text-sm font-semibold">EV Assistant Bot</p>
                <p className="text-[11px] text-muted-foreground-2">Here to guide you</p>
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              aria-label="Close assistant"
              className="rounded-lg px-2 py-1 text-muted-foreground hover:bg-surface-2"
            >
              ✕
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-3.5 py-2.5 text-[13.5px] leading-relaxed ${
                  message.role === "user"
                    ? "ml-auto bg-surface-2 text-foreground"
                    : "border border-border bg-surface text-muted-foreground"
                }`}
              >
                {message.content}
              </div>
            ))}
            {busy && (
              <div className="w-fit rounded-2xl border border-border bg-surface px-3.5 py-2.5 text-[13px] text-muted-foreground-2">
                EV Assistant Bot is typing…
              </div>
            )}
            {messages.length === 1 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    className="rounded-full border border-border px-3 py-1.5 text-[12px] text-muted-foreground hover:bg-surface-2"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}
          </div>

          <form
            onSubmit={(event) => {
              event.preventDefault();
              void send(input);
            }}
            className="flex gap-2 border-t border-border bg-surface px-3 py-3"
          >
            <input
              ref={inputRef}
              value={input}
              onChange={(event) => setInput(event.target.value)}
              placeholder="Ask about products or delivery…"
              className="flex-1 rounded-full border border-border bg-surface-2 px-4 py-2.5 text-sm outline-none focus:border-brand-violet"
            />
            <button
              type="submit"
              disabled={busy || !input.trim()}
              className="rounded-full px-4 py-2.5 text-sm font-semibold text-primary-foreground gradient-fill disabled:opacity-60"
            >
              Send
            </button>
          </form>
        </div>
      )}
    </>
  );
}
