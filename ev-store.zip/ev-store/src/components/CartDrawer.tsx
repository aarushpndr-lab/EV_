import { Link } from "@tanstack/react-router";

import { useCart } from "@/lib/cart";
import { formatPrice, FREE_SHIPPING_ABOVE } from "@/lib/products";

export function CartDrawer() {
  const { lines, drawerOpen, closeDrawer, setQty, remove, subtotal, shipping, total } = useCart();

  return (
    <>
      <div
        onClick={closeDrawer}
        className={`fixed inset-0 z-[60] bg-background/70 backdrop-blur-sm transition-opacity ${
          drawerOpen ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      />
      <aside
        className={`fixed right-0 top-0 z-[70] flex h-full w-full max-w-[400px] flex-col border-l border-border bg-surface transition-transform duration-300 ${
          drawerOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between border-b border-border px-6 py-5">
          <h3 className="text-lg font-semibold">Your cart</h3>
          <button
            onClick={closeDrawer}
            aria-label="Close cart"
            className="flex h-9 w-9 items-center justify-center rounded-xl text-muted-foreground hover:bg-surface-2 hover:text-foreground"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M5 5l14 14M19 5L5 19" />
            </svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-5">
          {lines.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Your cart is empty. Add something from new arrivals.
            </p>
          ) : (
            <ul className="space-y-4">
              {lines.map((line) => (
                <li key={line.id} className="rounded-xl border border-border bg-surface-2 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-display text-sm font-semibold">{line.name}</p>
                      <p className="mt-1 font-mono text-xs text-muted-foreground">
                        {formatPrice(line.price)}
                      </p>
                    </div>
                    <button
                      onClick={() => remove(line.id)}
                      className="text-xs text-muted-foreground-2 hover:text-destructive"
                    >
                      Remove
                    </button>
                  </div>
                  <div className="mt-3 flex items-center gap-3">
                    <button
                      onClick={() => setQty(line.id, line.qty - 1)}
                      className="h-8 w-8 rounded-lg border border-border text-sm"
                      aria-label={`Decrease ${line.name}`}
                    >
                      −
                    </button>
                    <span className="w-6 text-center font-mono text-sm">{line.qty}</span>
                    <button
                      onClick={() => setQty(line.id, line.qty + 1)}
                      className="h-8 w-8 rounded-lg border border-border text-sm"
                      aria-label={`Increase ${line.name}`}
                    >
                      +
                    </button>
                    <span className="ml-auto font-mono text-sm">
                      {formatPrice(line.price * line.qty)}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {lines.length > 0 && (
          <div className="border-t border-border px-6 py-5">
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Subtotal</dt>
                <dd className="font-mono">{formatPrice(subtotal)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Shipping</dt>
                <dd className="font-mono">{shipping === 0 ? "Free" : formatPrice(shipping)}</dd>
              </div>
              <div className="flex justify-between border-t border-border pt-2 text-base font-semibold">
                <dt>Total</dt>
                <dd className="font-mono">{formatPrice(total)}</dd>
              </div>
            </dl>
            {shipping > 0 && (
              <p className="mt-2 text-xs text-muted-foreground-2">
                Free shipping over {formatPrice(FREE_SHIPPING_ABOVE)}.
              </p>
            )}
            <Link
              to="/checkout"
              onClick={closeDrawer}
              className="mt-4 block w-full rounded-full py-3 text-center text-sm font-semibold text-primary-foreground gradient-fill"
            >
              Checkout
            </Link>
          </div>
        )}
      </aside>
    </>
  );
}
