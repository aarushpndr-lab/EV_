import { useEffect, useState } from "react";

import { PRODUCTS, formatPrice } from "@/lib/products";

const SLIDE_MS = 3200;

/**
 * ProductReel — an auto-playing showcase that crossfades through every product
 * photo with a slow zoom, so a stack of stills reads like a running video.
 * Add a product in src/lib/products.ts and it joins the reel automatically.
 */
export function ProductReel() {
  const slides = PRODUCTS.filter((p) => p.image);
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused || slides.length <= 1) return;
    const id = window.setInterval(() => {
      setIndex((i) => (i + 1) % slides.length);
    }, SLIDE_MS);
    return () => window.clearInterval(id);
  }, [paused, slides.length]);

  if (slides.length === 0) return null;
  const active = slides[index]!;

  return (
    <div
      className="relative overflow-hidden rounded-3xl border border-border bg-surface shadow-2xl"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      aria-roledescription="carousel"
      aria-label="EV product showcase"
    >
      <div className="relative aspect-[4/5] w-full sm:aspect-[4/3]">
        {slides.map((product, i) => (
          <img
            key={product.id}
            src={product.image}
            alt={product.name}
            loading={i === 0 ? "eager" : "lazy"}
            aria-hidden={i !== index}
            className={`reel-slide absolute inset-0 h-full w-full object-contain p-4 ${
              i === index ? "reel-slide-active" : ""
            }`}
          />
        ))}

        {/* scanning light bar — sells the "running video" feel */}
        <div className="reel-scan pointer-events-none absolute inset-0" aria-hidden />

        <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-background/90 to-transparent p-5 pt-14">
          <p className="text-[11px] uppercase tracking-wider text-brand-cyan">{active.category}</p>
          <p className="font-display text-lg font-semibold">{active.name}</p>
          <p className="font-mono text-sm text-muted-foreground">{formatPrice(active.price)}</p>
        </div>
      </div>

      <div className="flex items-center gap-2 border-t border-border bg-surface-2/60 px-4 py-3">
        {slides.map((product, i) => (
          <button
            key={product.id}
            onClick={() => setIndex(i)}
            aria-label={`Show ${product.name}`}
            aria-current={i === index}
            className="group relative h-1.5 flex-1 overflow-hidden rounded-full bg-border"
          >
            <span
              className={`absolute inset-y-0 left-0 rounded-full gradient-fill transition-[width] ${
                i === index ? "reel-bar" : i < index ? "w-full" : "w-0"
              }`}
              style={i === index && !paused ? { animationDuration: `${SLIDE_MS}ms` } : undefined}
            />
          </button>
        ))}
      </div>
    </div>
  );
}
