import { Link } from "@tanstack/react-router";

import logoAsset from "@/assets/ev-logo-brand.png.asset.json";

const COLUMNS = [
  {
    title: "Shop",
    links: ["Phones", "Laptops", "Audio", "Wearables"],
  },
  {
    title: "Support",
    links: ["Track an order", "Returns", "Warranty", "Contact us"],
  },
  {
    title: "Company",
    links: ["About EV", "Sell on EV", "Privacy policy", "Terms"],
  },
];

export function Footer() {
  return (
    <footer id="support" className="border-t border-border bg-surface/50 py-16">
      <div className="wrap">
        <div className="grid gap-12 md:grid-cols-[1.4fr_repeat(3,1fr)]">
          <div>
            <Link to="/" className="flex items-center gap-2 font-display text-[22px] font-bold">
              <img src={logoAsset.url} alt="EV logo" width={28} height={28} loading="lazy" className="h-7 w-7 rounded-md object-cover" />
              EV
            </Link>
            <p className="mt-4 max-w-xs text-sm text-muted-foreground">
              A marketplace for phones, laptops, audio and everyday electronics. Built for people who
              just want good gear at a fair price.
            </p>
            <a
              href="tel:+917078364227"
              className="mt-5 inline-flex items-center gap-2 rounded-full border border-border bg-surface px-4 py-2.5 text-sm font-semibold transition-colors hover:border-brand-violet hover:bg-surface-2"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.5 2.8.6a2 2 0 0 1 1.7 2Z" />
              </svg>
              Call support · +91 70783 64227
            </a>
          </div>




          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h4 className="text-sm font-semibold">{col.title}</h4>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((link) => (
                  <li key={link}>
                    <Link
                      to="/"
                      hash="products"
                      className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {link}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-6 text-xs text-muted-foreground-2">
          <span>© {new Date().getFullYear()} EV. All rights reserved.</span>
          <span>Secure accounts · Real orders · Scheduled delivery</span>
        </div>
      </div>
    </footer>
  );
}
