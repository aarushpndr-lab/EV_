import { Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";

import logoAsset from "@/assets/ev-logo-brand.png.asset.json";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { useIsAdmin } from "@/lib/use-admin";

const NAV = [
  { label: "New arrivals", to: "/", hash: "products" },
  { label: "Categories", to: "/", hash: "categories" },
  { label: "Deals", to: "/", hash: "products" },
  { label: "Support", to: "/", hash: "support" },
];

export function Header() {
  const { count, openDrawer } = useCart();
  const { user, profile } = useAuth();
  const { isAdmin } = useIsAdmin();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [menuOpen, setMenuOpen] = useState(false);

  const signOut = async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
      <nav className="wrap flex items-center justify-between py-4">
        <Link to="/" className="flex items-center gap-2 font-display text-[22px] font-bold">
          <img src={logoAsset.url} alt="EV logo" width={28} height={28} className="h-7 w-7 rounded-md object-cover" />
          EV
        </Link>

        <ul className="hidden items-center gap-8 md:flex">
          {NAV.map((item) => (
            <li key={item.label}>
              <Link
                to={item.to}
                hash={item.hash}
                className="font-display text-[14.5px] font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                {item.label}
              </Link>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-3">
          <button
            onClick={openDrawer}
            aria-label="Cart"
            className="relative flex h-9 w-9 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-surface hover:text-foreground"
          >
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M6 2l1.5 4h13L19 15H8L6 2z" />
              <circle cx="9" cy="20" r="1.6" />
              <circle cx="18" cy="20" r="1.6" />
            </svg>
            {count > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand-violet px-1 text-[10px] font-semibold text-primary-foreground">
                {count}
              </span>
            )}
          </button>

          {user ? (
            <div className="relative">
              <button
                onClick={() => setMenuOpen((v) => !v)}
                className="flex items-center gap-2 rounded-full border border-border px-3 py-2 text-sm font-medium"
              >
                <span className="h-6 w-6 rounded-full gradient-fill" aria-hidden />
                <span className="hidden max-w-28 truncate sm:block">
                  {profile?.full_name || user.email}
                </span>
              </button>
              {menuOpen && (
                <div className="absolute right-0 mt-2 w-48 overflow-hidden rounded-xl border border-border bg-popover shadow-xl">
                  <Link
                    to="/orders"
                    onClick={() => setMenuOpen(false)}
                    className="block px-4 py-3 text-sm hover:bg-surface-2"
                  >
                    My orders
                  </Link>
                  <Link
                    to="/account"
                    onClick={() => setMenuOpen(false)}
                    className="block px-4 py-3 text-sm hover:bg-surface-2"
                  >
                    My details
                  </Link>
                  {isAdmin && (
                    <Link
                      to="/admin"
                      onClick={() => setMenuOpen(false)}
                      className="block px-4 py-3 text-sm font-medium hover:bg-surface-2"
                    >
                      Admin control room
                    </Link>
                  )}
                  {isAdmin && (
                    <Link
                      to="/admin-inbox"
                      onClick={() => setMenuOpen(false)}
                      className="block px-4 py-3 text-sm font-medium hover:bg-surface-2"
                    >
                      Order email inbox
                    </Link>
                  )}
                  <button
                    onClick={signOut}
                    className="block w-full px-4 py-3 text-left text-sm text-muted-foreground hover:bg-surface-2"
                  >
                    Sign out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link
              to="/auth"
              className="rounded-full px-5 py-2.5 text-sm font-semibold text-primary-foreground gradient-fill"
            >
              Sign in
            </Link>
          )}
        </div>
      </nav>
    </header>
  );
}
