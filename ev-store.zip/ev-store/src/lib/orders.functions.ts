import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { PRODUCTS, FREE_SHIPPING_ABOVE, SHIPPING_FEE, DELIVERY_SLOTS } from "./products";

const orderInput = z.object({
  items: z
    .array(z.object({ id: z.string().min(1), qty: z.number().int().min(1).max(20) }))
    .min(1)
    .max(20),
  customer_name: z.string().trim().min(2).max(100),
  customer_phone: z.string().trim().min(6).max(20),
  delivery_address: z.string().trim().min(5).max(300),
  delivery_city: z.string().trim().min(2).max(100),
  delivery_postal_code: z.string().trim().min(3).max(12),
  delivery_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  delivery_slot: z.enum(DELIVERY_SLOTS),
  payment_method: z.enum(["card", "cod", "bank"]),
  payment_reference: z.string().trim().max(120).optional(),
  notes: z.string().trim().max(500).optional(),
});

export type PlaceOrderInput = z.infer<typeof orderInput>;

export const placeOrder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => orderInput.parse(data))
  .handler(async ({ data, context }) => {
    // Deliveries always start one week out — no same-day or next-day slots.
    const earliest = new Date();
    earliest.setHours(0, 0, 0, 0);
    earliest.setDate(earliest.getDate() + 7);
    if (new Date(`${data.delivery_date}T00:00:00`) < earliest) {
      throw new Error(
        `Earliest delivery date is ${earliest.toISOString().slice(0, 10)} — we deliver one week after the order.`,
      );
    }

    // Prices come from the server catalog, never from the browser.
    const items = data.items.map((line) => {
      const product = PRODUCTS.find((p) => p.id === line.id);
      if (!product) throw new Error(`Unknown product: ${line.id}`);
      return {
        id: product.id,
        name: product.name,
        category: product.category,
        price: product.price,
        qty: line.qty,
        line_total: product.price * line.qty,
      };
    });

    const subtotal = items.reduce((sum, i) => sum + i.line_total, 0);
    const shipping = subtotal >= FREE_SHIPPING_ABOVE ? 0 : SHIPPING_FEE;
    const total = subtotal + shipping;

    const paymentStatus =
      data.payment_method === "cod"
        ? "pending_on_delivery"
        : data.payment_method === "bank"
          ? "awaiting_transfer_check"
          : "awaiting_card_payment";

    const { data: order, error } = await context.supabase
      .from("orders")
      .insert({
        user_id: context.userId,
        items,
        subtotal,
        shipping,
        total,
        payment_method: data.payment_method,
        payment_status: paymentStatus,
        payment_reference: data.payment_reference ?? null,
        status: "placed",
        customer_name: data.customer_name,
        customer_email: context.claims.email ?? "",
        customer_phone: data.customer_phone,
        delivery_address: data.delivery_address,
        delivery_city: data.delivery_city,
        delivery_postal_code: data.delivery_postal_code,
        delivery_date: data.delivery_date,
        delivery_slot: data.delivery_slot,
        eta_date: data.delivery_date,
        notes: data.notes ?? null,
      })
      .select(
        "id, order_number, total, payment_method, payment_status, delivery_date, delivery_slot, eta_date, status",
      )
      .single();

    if (error) throw new Error(error.message);

    const { notifyOwnerOfOrder } = await import("./order-notify.server");
    await notifyOwnerOfOrder({ ...order, items, customer: data, email: context.claims.email ?? "" });

    return order;
  });
