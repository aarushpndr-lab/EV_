import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ORDER_STATUSES = [
  "placed",
  "confirmed",
  "packed",
  "shipped",
  "out_for_delivery",
  "delivered",
  "cancelled",
] as const;

const PAYMENT_STATUSES = [
  "pending",
  "pending_on_delivery",
  "awaiting_transfer_check",
  "awaiting_card_payment",
  "paid",
  "refunded",
  "failed",
] as const;

async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data, error } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (error) throw new Error("Could not verify admin access");
  if (!data) throw new Error("Forbidden: admin access required");
}

export const checkAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    return { isAdmin: data === true };
  });

export const adminOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);

    const [ordersRes, profilesRes] = await Promise.all([
      context.supabase
        .from("orders")
        .select(
          "id, order_number, created_at, updated_at, status, payment_method, payment_status, payment_reference, subtotal, shipping, total, items, customer_name, customer_email, customer_phone, delivery_address, delivery_city, delivery_postal_code, delivery_date, delivery_slot, carrier, tracking_number, eta_date, notes, user_id, order_events(id, status, message, created_at)",
        )
        .order("created_at", { ascending: false })
        .limit(500),
      context.supabase
        .from("profiles")
        .select("id, full_name, phone, address, city, postal_code, created_at")
        .order("created_at", { ascending: false })
        .limit(500),
    ]);

    if (ordersRes.error) throw new Error(ordersRes.error.message);
    if (profilesRes.error) throw new Error(profilesRes.error.message);

    const orders = ordersRes.data ?? [];
    const revenue = orders
      .filter((o: any) => o.status !== "cancelled")
      .reduce((sum: number, o: any) => sum + Number(o.total ?? 0), 0);
    const collected = orders
      .filter((o: any) => o.payment_status === "paid")
      .reduce((sum: number, o: any) => sum + Number(o.total ?? 0), 0);

    const byStatus: Record<string, number> = {};
    for (const o of orders) byStatus[o.status] = (byStatus[o.status] ?? 0) + 1;

    return {
      orders,
      customers: profilesRes.data ?? [],
      stats: {
        orderCount: orders.length,
        revenue,
        collected,
        pendingPayment: orders.filter((o: any) => o.payment_status !== "paid").length,
        delivered: byStatus["delivered"] ?? 0,
        byStatus,
      },
    };
  });

export const updateOrder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        status: z.enum(ORDER_STATUSES).optional(),
        payment_status: z.enum(PAYMENT_STATUSES).optional(),
        carrier: z.string().trim().max(80).optional(),
        tracking_number: z.string().trim().max(80).optional(),
        eta_date: z
          .string()
          .regex(/^\d{4}-\d{2}-\d{2}$/)
          .optional(),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);

    const patch: {
      status?: string;
      payment_status?: string;
      carrier?: string | null;
      tracking_number?: string | null;
      eta_date?: string;
    } = {};
    if (data.status) patch.status = data.status;
    if (data.payment_status) patch.payment_status = data.payment_status;
    if (data.carrier !== undefined) patch.carrier = data.carrier || null;
    if (data.tracking_number !== undefined) patch.tracking_number = data.tracking_number || null;
    if (data.eta_date) patch.eta_date = data.eta_date;

    if (Object.keys(patch).length === 0) return { ok: true };

    const { error } = await context.supabase.from("orders").update(patch).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
