export type Product = {
  id: string;
  name: string;
  category: string;
  desc: string;
  price: number;
  oldPrice?: number;
  badge?: string;
  image?: string;
};

export const CURRENCY = "₹";

export function formatPrice(value: number) {
  return `${CURRENCY}${value.toLocaleString("en-IN")}`;
}

import phoneOne from "@/assets/ev-phone-one.webp.asset.json";
import bookOne from "@/assets/ev-book-one.webp.asset.json";
import notebookOne from "@/assets/ev-notebook-one.webp.asset.json";
import aiGlasses from "@/assets/ev-ai-glasses.webp.asset.json";
import evTv from "@/assets/ev-tv.webp.asset.json";
import evAssistant from "@/assets/ev-assistant.webp.asset.json";
import evTshirt from "@/assets/ev-tshirt.png.asset.json";
import evConsole from "@/assets/ev-console-one.png.asset.json";
import evHead from "@/assets/ev-head.png.asset.json";
import evBuds from "@/assets/ev-buds.png.asset.json";

export const CATEGORIES = [
  "Phones",
  "Laptops",
  "Tablets",
  "Audio",
  "Wearables",
  "Smart Home",
  "TV",
  "Gaming",
  "Apparel",
] as const;

/**
 * PRODUCTS — the only place to add, edit or remove a listing.
 * Leave `image` empty to keep the animated placeholder until a real photo exists.
 */
export const PRODUCTS: Product[] = [
  {
    id: "ev-phone-one",
    name: "EV Phone One",
    category: "Phones",
    desc: '6.67" AMOLED 120Hz · Snapdragon 8 Gen 3 · 5000mAh 80W',
    price: 49999,
    badge: "New",
    image: phoneOne.url,
  },
  {
    id: "ev-book-one",
    name: "EV Book One",
    category: "Laptops",
    desc: '14" 2.8K OLED · Core Ultra 7 · 32GB / 1TB',
    price: 89990,
    badge: "New",
    image: bookOne.url,
  },
  {
    id: "ev-notebook-one",
    name: "EV Notebook One",
    category: "Tablets",
    desc: '11.6" 2.8K 120Hz · Snapdragon 8 Gen 2 · 10000mAh',
    price: 24999,
    image: notebookOne.url,
  },
  {
    id: "ev-ai-glasses",
    name: "EV AI Glasses",
    category: "Wearables",
    desc: "Dual AR display · On-device AI · 8h+ battery",
    price: 34999,
    badge: "New",
    image: aiGlasses.url,
  },
  {
    id: "ev-tv",
    name: "EV TV 4K",
    category: "TV",
    desc: "4K Ultra HD · EV OS · EV Cinematic Sound",
    price: 54999,
    image: evTv.url,
  },
  {
    id: "ev-assistant",
    name: "EV Assistant",
    category: "Smart Home",
    desc: "360° mic array · Premium sound · Wi-Fi & BT 5.0",
    price: 7999,
    image: evAssistant.url,
  },
  {
    id: "ev-tee",
    name: "EV Oversized Tee",
    category: "Apparel",
    desc: "240 GSM cotton · Limited edition drop",
    price: 1299,
    badge: "Limited",
    image: evTshirt.url,
  },
  {
    id: "ev-console-one",
    name: "EV Console 1 Digital Edition",
    category: "Gaming",
    desc: "Custom EV chip · 1TB SSD · 16GB GDDR6 · Wi-Fi 7 · disc-free 4K gaming",
    price: 39999,
    badge: "New",
    image: evConsole.url,
  },
  {
    id: "ev-head",
    name: "EV Head",
    category: "Audio",
    desc: "Hi-Fi stereo · 50h battery · EV Assistant ready · Bluetooth 5.3",
    price: 9999,
    badge: "New",
    image: evHead.url,
  },
  {
    id: "ev-buds",
    name: "EV Buds",
    category: "Audio",
    desc: "30h with case · IPX5 · touch controls · Bluetooth 5.3",
    price: 4999,
    badge: "New",
    image: evBuds.url,
  },
];



export const DELIVERY_SLOTS = [
  "Morning · 9:00 AM – 12:00 PM",
  "Afternoon · 12:00 PM – 4:00 PM",
  "Evening · 4:00 PM – 8:00 PM",
  "Night · 8:00 PM – 10:00 PM",
] as const;

export const FREE_SHIPPING_ABOVE = 7500;
export const SHIPPING_FEE = 249;
