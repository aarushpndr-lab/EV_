/**
 * Owner notification for a new order.
 *
 * Email delivery through Lovable Emails needs a verified sender domain that the
 * store owner owns. Until that domain is set up, every order is logged here in
 * full (and is always visible in the app's own order records and the admin
 * inbox page), and the same payload is what will be emailed once the domain is
 * verified.
 */

import {
  OWNER_EMAIL,
  buildOrderEmailHtml,
  buildOrderEmailText,
  type OrderEmailPayload,
} from "./order-email";

export { OWNER_EMAIL };
export type NotifyPayload = OrderEmailPayload;

export async function notifyOwnerOfOrder(payload: NotifyPayload) {
  const html = buildOrderEmailHtml(payload);
  const text = buildOrderEmailText(payload);

  // Until a verified sender domain is connected, the full formatted email is
  // logged here (and previewable in the admin inbox page).
  console.info(
    `NEW ORDER ${payload.order_number} → notify ${OWNER_EMAIL}\n${text}\n--- HTML EMAIL ---\n${html}`,
  );
}
