/**
 * Shared order-email builder (client-safe): used by the server to send/log the
 * owner notification and by the admin inbox page to preview the exact same
 * formatted email.
 */

export const OWNER_EMAIL = "aarushpndr@gmail.com";

export type OrderEmailItem = {
  name: string;
  qty: number;
  price: number;
  line_total: number;
};

export type OrderEmailPayload = {
  order_number: string;
  total: number;
  payment_method: string;
  payment_status: string;
  delivery_date: string | null;
  delivery_slot: string;
  email: string;
  items: OrderEmailItem[];
  customer: {
    customer_name: string;
    customer_phone: string;
    delivery_address: string;
    delivery_city: string;
    delivery_postal_code: string;
    notes?: string | undefined;
  };
};

const inr = (n: number) => `₹${n.toLocaleString("en-IN")}`;

const esc = (s: string) =>
  s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

/** Fully formatted HTML order email for the store owner. */
export function buildOrderEmailHtml(p: OrderEmailPayload): string {
  const address = `${p.customer.delivery_address}, ${p.customer.delivery_city} ${p.customer.delivery_postal_code}`;
  const itemRows = p.items
    .map(
      (i) => `
        <tr>
          <td style="padding:10px 12px;border-top:1px solid #e5e7eb;font-size:14px;color:#111827;">${i.qty} × ${esc(i.name)}</td>
          <td style="padding:10px 12px;border-top:1px solid #e5e7eb;font-size:14px;color:#111827;text-align:right;font-family:monospace;">${inr(i.line_total)}</td>
        </tr>`,
    )
    .join("");

  const field = (label: string, value: string) => `
        <tr>
          <td style="padding:6px 0;font-size:12px;color:#6b7280;width:120px;vertical-align:top;">${label}</td>
          <td style="padding:6px 0;font-size:14px;color:#111827;">${value}</td>
        </tr>`;

  return `<!doctype html>
<html lang="en">
  <body style="margin:0;padding:0;background:#f3f4f6;font-family:Arial,Helvetica,sans-serif;">
    <div style="max-width:560px;margin:0 auto;padding:24px 12px;">
      <div style="background:#0b0f1a;border-radius:16px 16px 0 0;padding:20px 24px;">
        <p style="margin:0;font-size:20px;font-weight:bold;color:#22d3ee;letter-spacing:2px;">EV</p>
        <p style="margin:4px 0 0;font-size:13px;color:#9ca3af;">New order received</p>
      </div>
      <div style="background:#ffffff;padding:24px;border-radius:0 0 16px 16px;">
        <h1 style="margin:0 0 4px;font-size:20px;color:#111827;">Someone just ordered from EV</h1>
        <p style="margin:0 0 16px;font-size:14px;color:#6b7280;">Order <strong>${esc(p.order_number)}</strong> · ${inr(p.total)}</p>

        <h2 style="margin:0 0 8px;font-size:13px;text-transform:uppercase;letter-spacing:1px;color:#6b7280;">Customer</h2>
        <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
          ${field("Name", esc(p.customer.customer_name))}
          ${field("Email", esc(p.email))}
          ${field("Phone", esc(p.customer.customer_phone))}
          ${field("Deliver to", esc(address))}
          ${field("Delivery time", `${esc(p.delivery_date ?? "-")} · ${esc(p.delivery_slot)}`)}
          ${field("Payment", `${esc(p.payment_method)} (${esc(p.payment_status)})`)}
        </table>

        <h2 style="margin:0 0 8px;font-size:13px;text-transform:uppercase;letter-spacing:1px;color:#6b7280;">Items</h2>
        <table style="width:100%;border-collapse:collapse;">
          ${itemRows}
          <tr>
            <td style="padding:12px;border-top:2px solid #111827;font-size:15px;font-weight:bold;color:#111827;">Total</td>
            <td style="padding:12px;border-top:2px solid #111827;font-size:15px;font-weight:bold;color:#111827;text-align:right;font-family:monospace;">${inr(p.total)}</td>
          </tr>
        </table>

        ${
          p.customer.notes
            ? `<p style="margin:16px 0 0;font-size:13px;color:#374151;background:#f9fafb;border-radius:8px;padding:10px 12px;"><strong>Notes:</strong> ${esc(p.customer.notes)}</p>`
            : ""
        }
      </div>
      <p style="margin:12px 0 0;text-align:center;font-size:11px;color:#9ca3af;">EV store · order notification</p>
    </div>
  </body>
</html>`;
}

/** Plain-text fallback of the same email. */
export function buildOrderEmailText(p: OrderEmailPayload): string {
  const lines = p.items
    .map((i) => `  • ${i.qty} × ${i.name} — ${inr(i.line_total)}`)
    .join("\n");
  return [
    `NEW ORDER ${p.order_number}`,
    `Name: ${p.customer.customer_name}`,
    `Email: ${p.email}`,
    `Phone: ${p.customer.customer_phone}`,
    `Deliver to: ${p.customer.delivery_address}, ${p.customer.delivery_city} ${p.customer.delivery_postal_code}`,
    `Delivery: ${p.delivery_date ?? "-"} · ${p.delivery_slot}`,
    `Payment: ${p.payment_method} (${p.payment_status})`,
    `Total: ${inr(p.total)}`,
    `Items:\n${lines}`,
    p.customer.notes ? `Notes: ${p.customer.notes}` : "",
  ]
    .filter(Boolean)
    .join("\n");
}
