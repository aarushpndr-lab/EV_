import { useQuery } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

/** Reads the signed-in user's own role rows (RLS-scoped). UI hint only —
 * every admin server function re-verifies the role server-side. */
export function useIsAdmin() {
  const { user } = useAuth();

  const { data, isLoading } = useQuery({
    queryKey: ["is-admin", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data: rows, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user!.id);
      if (error) throw new Error(error.message);
      return (rows ?? []).some((r) => r.role === "admin");
    },
  });

  return { isAdmin: data === true, loading: !!user && isLoading };
}
