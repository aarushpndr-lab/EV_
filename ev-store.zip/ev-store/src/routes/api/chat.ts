import { createFileRoute } from "@tanstack/react-router";

import { PRODUCTS, DELIVERY_SLOTS, FREE_SHIPPING_ABOVE, SHIPPING_FEE, formatPrice } from "@/lib/products";

type ChatMessage = { role: "user" | "assistant"; content: string };

const catalogue = PRODUCTS.map(
  (p) => `- ${p.name} (${p.category}) — ${formatPrice(p.price)} · ${p.desc} · status: Coming soon`,
).join("\n");

const SYSTEM_PROMPT = `You are "EV Assistant Bot", the friendly shopping guide for the EV electronics store.
Guide every customer: help them pick a product, explain how to create an account, how checkout works, payment options and delivery.

Store facts you must follow:
- Catalogue (every product is marked "Coming soon" — pre-orders are accepted, stock ships later):
${catalogue}
- Free shipping above ${formatPrice(FREE_SHIPPING_ABOVE)}, otherwise ${formatPrice(SHIPPING_FEE)} shipping.
- Payment options at checkout: card/UPI online, bank transfer, or cash on delivery.
- Delivery: we never deliver same-day or next-day. The earliest delivery date is one week (7 days) after the order.
- Delivery time windows: ${DELIVERY_SLOTS.join(" | ")}.
- Customers must sign in (name, phone, address, city, PIN are saved to their account) before checkout.
- Order confirmations are sent to the store owner, who contacts the customer.

Be concise (max ~120 words), warm and specific. Never invent products, prices or faster delivery. If unsure, say you'll pass it to the EV team.`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json()) as { messages?: ChatMessage[] };
        const messages = Array.isArray(body.messages) ? body.messages.slice(-20) : null;
        if (!messages) return new Response("Messages are required", { status: 400 });

        const key = process.env["LOVABLE_API_KEY"];
        if (!key) return new Response("AI is not configured", { status: 500 });

        const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
          body: JSON.stringify({
            model: "google/gemini-3.6-flash",
            messages: [
              { role: "system", content: SYSTEM_PROMPT },
              ...messages.map((m) => ({
                role: m.role,
                content: String(m.content ?? "").slice(0, 2000),
              })),
            ],
          }),
        });

        if (!response.ok) {
          const detail = await response.text();
          console.error("EV Assistant Bot gateway error", response.status, detail);
          const message =
            response.status === 429
              ? "The assistant is busy right now — please try again in a moment."
              : "The assistant is unavailable right now. Please try again shortly.";
          return new Response(JSON.stringify({ error: message }), {
            status: response.status === 429 ? 429 : 502,
            headers: { "content-type": "application/json" },
          });
        }

        const data = (await response.json()) as {
          choices?: { message?: { content?: string } }[];
        };
        const reply = data.choices?.[0]?.message?.content?.trim() ?? "";

        return new Response(JSON.stringify({ reply }), {
          headers: { "content-type": "application/json", "cache-control": "no-store" },
        });
      },
    },
  },
});
