import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";

import logoAsset from "@/assets/ev-logo-brand.png.asset.json";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in or create your EV account" },
      {
        name: "description",
        content:
          "Create an EV account with your name, phone and delivery address, or sign in to track orders and check out faster.",
      },
      { property: "og:title", content: "Sign in to EV" },
      {
        property: "og:description",
        content: "Save your delivery details once and check out in seconds on EV.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

const signUpSchema = z.object({
  full_name: z.string().trim().min(2, "Enter your full name").max(100),
  phone: z.string().trim().min(6, "Enter a valid phone number").max(20),
  address: z.string().trim().min(5, "Enter your delivery address").max(300),
  city: z.string().trim().min(2, "Enter your city").max(100),
  postal_code: z.string().trim().min(3, "Enter your postal code").max(12),
  email: z.string().trim().email("Enter a valid email").max(255),
  password: z.string().min(8, "Use at least 8 characters").max(72),
});

const inputClass =
  "w-full rounded-xl border border-border bg-surface-2 px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground-2 focus:border-brand-violet";

function AuthPage() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && user) navigate({ to: "/", replace: true });
  }, [loading, user, navigate]);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setInfo(null);
    setBusy(true);

    const form = new FormData(event.currentTarget);
    try {
      if (mode === "signin") {
        const email = String(form.get("email") ?? "").trim();
        const password = String(form.get("password") ?? "");
        const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (signInError) {
          throw new Error(
            /invalid login/i.test(signInError.message)
              ? "That email and password don't match an EV account. Check them, or create an account below."
              : signInError.message,
          );
        }
        if (!signInData.session) throw new Error("Could not start your session. Please try again.");
        navigate({ to: "/", replace: true });
        return;
      }

      const parsed = signUpSchema.parse({
        full_name: form.get("full_name"),
        phone: form.get("phone"),
        address: form.get("address"),
        city: form.get("city"),
        postal_code: form.get("postal_code"),
        email: form.get("email"),
        password: form.get("password"),
      });

      const { data, error: signUpError } = await supabase.auth.signUp({
        email: parsed.email,
        password: parsed.password,
        options: {
          emailRedirectTo: window.location.origin,
          data: {
            full_name: parsed.full_name,
            phone: parsed.phone,
            address: parsed.address,
            city: parsed.city,
            postal_code: parsed.postal_code,
          },
        },
      });
      if (signUpError) throw new Error(signUpError.message);

      if (data.session) {
        navigate({ to: "/", replace: true });
      } else {
        setInfo("Account created. Sign in with your email and password to continue.");
        setMode("signin");
      }
    } catch (err) {
      setError(err instanceof z.ZodError ? err.issues[0]!.message : (err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const signInWithGoogle = async () => {
    setError(null);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setError("Google sign-in failed. Please try again.");
      return;
    }
    if (result.redirected) return;
    navigate({ to: "/", replace: true });
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-16">
      <div className="glow-blob" aria-hidden />
      <div className="relative w-full max-w-md rounded-3xl border border-border bg-surface p-8">
        <Link to="/" className="flex items-center gap-2 font-display text-xl font-bold">
          <img src={logoAsset.url} alt="EV logo" width={28} height={28} className="h-7 w-7 rounded-md object-cover" />
          EV
        </Link>

        <h1 className="mt-6 font-display text-2xl font-bold tracking-tight">
          {mode === "signin" ? "Welcome back" : "Create your account"}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {mode === "signin"
            ? "Sign in to check out and track your orders."
            : "We save your name, phone and address so checkout takes seconds."}
        </p>
        <p className="mt-1 text-xs text-muted-foreground-2">
          You stay signed in on this device until you sign out.
        </p>

        <button
          onClick={signInWithGoogle}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl border border-border py-3 text-sm font-semibold transition-colors hover:bg-surface-2"
        >
          Continue with Google
        </button>

        <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground-2">
          <span className="h-px flex-1 bg-border" /> or use email <span className="h-px flex-1 bg-border" />
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          {mode === "signup" && (
            <>
              <input name="full_name" placeholder="Full name" required className={inputClass} />
              <input
                name="phone"
                type="tel"
                placeholder="Phone number"
                required
                className={inputClass}
              />
              <input
                name="address"
                placeholder="Delivery address (house, street, area)"
                required
                className={inputClass}
              />
              <div className="grid grid-cols-2 gap-3">
                <input name="city" placeholder="City" required className={inputClass} />
                <input name="postal_code" placeholder="PIN / ZIP" required className={inputClass} />
              </div>
            </>
          )}
          <input
            name="email"
            type="email"
            placeholder="Email address"
            required
            autoComplete="email"
            className={inputClass}
          />
          <input
            name="password"
            type="password"
            placeholder="Password"
            required
            minLength={8}
            autoComplete={mode === "signin" ? "current-password" : "new-password"}
            className={inputClass}
          />

          {error && <p className="text-sm text-destructive">{error}</p>}
          {info && <p className="text-sm text-brand-cyan">{info}</p>}

          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-full py-3 text-sm font-semibold text-primary-foreground gradient-fill disabled:opacity-60"
          >
            {busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}
          </button>
        </form>

        <p className="mt-5 text-center text-sm text-muted-foreground">
          {mode === "signin" ? "New to EV?" : "Already have an account?"}{" "}
          <button
            onClick={() => {
              setMode(mode === "signin" ? "signup" : "signin");
              setError(null);
              setInfo(null);
            }}
            className="font-semibold text-foreground underline-offset-4 hover:underline"
          >
            {mode === "signin" ? "Create an account" : "Sign in"}
          </button>
        </p>
      </div>
    </div>
  );
}
