import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";

import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { formatPrice } from "@/lib/products";
import { adminOverview } from "@/lib/admin.functions";
import { OWNER_EMAIL, buildOrderEmailHtml } from "@/lib/order-email";

export const Route = createFileRoute("/_authenticated/admin-inbox")({
  head: () => ({
    meta: [
      { title: "Order email inbox — EV" },
      {
        name: "description",
        content: "Preview every new-order email exactly as the store owner will receive it.",
      },
      { property: "og:title", content: "Order email inbox — EV" },
      { property: "og:description", content: "Owner-only preview of EV order notification emails." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: InboxPage,
});

type Item = { name: string; qty: number; line_total: number };

function InboxPage() {
  const fetchOverview = useServerFn(adminOverview);
  const { data, isLoading, error } = useQuery({
    queryKey: ["admin-inbox"],
    queryFn: () => fetchOverview(),
  });
  const [selected, setSelected] = useState<string | null>(null);
  const orders: any[] = data?.orders ?? [];
  const current = orders.find((o) => o.id === selected) ?? orders[0];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main className="mx-auto max-w-6xl px-4 py-10">
        <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="font-display text-3xl font-bold">Order email inbox</h1>
            <p className="text-sm text-muted-foreground">
              Preview of every new-order email for {OWNER_EMAIL}. Nothing is sent from here.
            </p>
          </div>
          <Link to="/admin" className="text-sm text-brand-cyan hover:underline">
            ← Admin control room
          </Link>
        </div>

        {isLoading && <p className="text-muted-foreground">Loading…</p>}
        {error && <p className="text-destructive">{(error as Error).message}</p>}
        {!isLoading && !error && orders.length === 0 && (
          <p className="text-muted-foreground">No orders yet — new order emails will appear here.</p>
        )}

        {orders.length > 0 && (
          <div className="grid gap-4 md:grid-cols-[320px_1fr]">
            <ul className="max-h-[70vh] overflow-y-auto rounded-2xl border border-border bg-surface">
              {orders.map((o) => (
                <li key={o.id}>
                  <button
                    onClick={() => setSelected(o.id)}
                    className={`block w-full border-b border-border px-4 py-3 text-left hover:bg-surface-2 ${
                      current?.id === o.id ? "bg-surface-2" : ""
                    }`}
                  >
                    <p className="text-sm font-semibold">New order {o.order_number}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {o.customer_name} · {formatPrice(Number(o.total))}
                    </p>
                    <p className="text-[11px] text-muted-foreground">
                      {new Date(o.created_at).toLocaleString("en-IN")}
                    </p>
                  </button>
                </li>
              ))}
            </ul>
            {current && <EmailPreview order={current} />}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

function EmailPreview({ order: o }: { order: any }) {
  const items: Item[] = Array.isArray(o.items) ? o.items : [];
  const html = buildOrderEmailHtml({
    order_number: o.order_number,
    total: Number(o.total),
    payment_method: o.payment_method,
    payment_status: o.payment_status,
    delivery_date: o.delivery_date ?? null,
    delivery_slot: o.delivery_slot,
    email: o.customer_email,
    items: items.map((i) => ({ ...i, price: 0 })),
    customer: {
      customer_name: o.customer_name,
      customer_phone: o.customer_phone,
      delivery_address: o.delivery_address,
      delivery_city: o.delivery_city,
      delivery_postal_code: o.delivery_postal_code,
      notes: o.notes ?? undefined,
    },
  });
  return (
    <article className="overflow-hidden rounded-2xl border border-border bg-surface">
      <div className="space-y-1 border-b border-border px-6 py-4 text-sm">
        <p><span className="text-muted-foreground">To:</span> {OWNER_EMAIL}</p>
        <p><span className="text-muted-foreground">Subject:</span> New order {o.order_number} — {formatPrice(Number(o.total))}</p>
        <p><span className="text-muted-foreground">Date:</span> {new Date(o.created_at).toLocaleString("en-IN")}</p>
      </div>
      <iframe
        title={`Order email ${o.order_number}`}
        srcDoc={html}
        sandbox=""
        className="h-[70vh] w-full bg-white"
      />
    </article>
  );
}
