import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";

import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { supabase } from "@/integrations/supabase/client";
import { formatPrice } from "@/lib/products";
import { OrderTracker, statusLabel, type TrackingEvent } from "@/components/OrderTracker";

export const Route = createFileRoute("/_authenticated/orders")({
  head: () => ({
    meta: [
      { title: "My orders — EV" },
      {
        name: "description",
        content: "Track every EV order: items, totals, payment status and your chosen delivery slot.",
      },
      { property: "og:title", content: "My orders — EV" },
      {
        property: "og:description",
        content: "Track your EV orders, payment status and delivery slots.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Orders,
});

type OrderRow = {
  id: string;
  order_number: string;
  created_at: string;
  status: string;
  payment_method: string;
  payment_status: string;
  total: number;
  delivery_date: string | null;
  delivery_slot: string | null;
  eta_date: string | null;
  carrier: string | null;
  tracking_number: string | null;
  items: { name: string; qty: number }[];
  order_events: TrackingEvent[];
};

function Orders() {
  const { data, isLoading } = useQuery({
    queryKey: ["orders"],
    queryFn: async () => {
      const { data: rows, error } = await supabase
        .from("orders")
        .select(
          "id, order_number, created_at, status, payment_method, payment_status, total, delivery_date, delivery_slot, eta_date, carrier, tracking_number, items, order_events(id, status, message, created_at)",
        )
        .order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return (rows ?? []) as unknown as OrderRow[];
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="wrap py-14">
        <h1 className="font-display text-3xl font-bold tracking-tight">My orders</h1>

        {isLoading && <p className="mt-6 text-sm text-muted-foreground">Loading your orders…</p>}

        {!isLoading && (data?.length ?? 0) === 0 && (
          <div className="mt-8 rounded-2xl border border-border bg-surface p-8 text-center">
            <p className="text-sm text-muted-foreground">You haven't placed an order yet.</p>
            <Link
              to="/"
              hash="products"
              className="mt-5 inline-block rounded-full px-5 py-2.5 text-sm font-semibold text-primary-foreground gradient-fill"
            >
              Start shopping
            </Link>
          </div>
        )}

        <div className="mt-8 space-y-4">
          {data?.map((order) => (
            <article key={order.id} className="rounded-2xl border border-border bg-surface p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-mono text-sm font-semibold">{order.order_number}</p>
                  <p className="mt-1 text-xs text-muted-foreground-2">
                    Placed {new Date(order.created_at).toLocaleDateString()}
                  </p>
                </div>
                <span className="rounded-full border border-border px-3 py-1 text-xs font-medium capitalize">
                  {statusLabel(order.status)}
                </span>
              </div>

              <ul className="mt-4 space-y-1 text-sm text-muted-foreground">
                {order.items?.map((item, index) => (
                  <li key={`${order.id}-${index}`}>
                    {item.qty} × {item.name}
                  </li>
                ))}
              </ul>

              <dl className="mt-4 grid gap-3 border-t border-border pt-4 text-sm sm:grid-cols-3">
                <div>
                  <dt className="text-xs text-muted-foreground-2">Total</dt>
                  <dd className="font-mono">{formatPrice(order.total)}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground-2">Payment</dt>
                  <dd className="capitalize">
                    {order.payment_method} · {order.payment_status.replace(/_/g, " ")}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground-2">Delivery slot</dt>
                  <dd>
                    {order.delivery_date ?? "—"}
                    {order.delivery_slot ? ` · ${order.delivery_slot}` : ""}
                  </dd>
                </div>
              </dl>

              <OrderTracker
                status={order.status}
                etaDate={order.eta_date ?? order.delivery_date}
                deliverySlot={order.delivery_slot}
                carrier={order.carrier}
                trackingNumber={order.tracking_number}
                events={[...(order.order_events ?? [])].sort(
                  (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime(),
                )}
              />
            </article>
          ))}
        </div>
      </main>

      <Footer />
    </div>
  );
}
