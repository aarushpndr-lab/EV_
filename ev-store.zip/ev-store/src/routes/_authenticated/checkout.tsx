import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useState } from "react";

import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useAuth } from "@/lib/auth";
import { useCart } from "@/lib/cart";
import { DELIVERY_SLOTS, formatPrice } from "@/lib/products";
import { placeOrder } from "@/lib/orders.functions";

export const Route = createFileRoute("/_authenticated/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — EV" },
      {
        name: "description",
        content:
          "Confirm your delivery details, choose a payment method and pick the delivery date and time slot for your EV order.",
      },
      { property: "og:title", content: "Checkout — EV" },
      {
        property: "og:description",
        content: "Confirm delivery details, pay your way and choose a delivery slot.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Checkout,
});

const inputClass =
  "w-full rounded-xl border border-border bg-surface-2 px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground-2 focus:border-brand-violet";

const PAYMENT_METHODS = [
  {
    id: "card" as const,
    title: "Card / UPI (online)",
    body: "You'll get payment instructions by email the moment the order is confirmed.",
  },
  {
    id: "bank" as const,
    title: "Bank transfer",
    body: "Transfer the total and add your reference number below so it can be matched.",
  },
  {
    id: "cod" as const,
    title: "Cash on delivery",
    body: "Pay the courier in cash when your order arrives.",
  },
];

/** Deliveries start one week out — no same-day or next-day slots. */
export const DELIVERY_LEAD_DAYS = 7;

function earliestDeliveryISO() {
  const date = new Date();
  date.setDate(date.getDate() + DELIVERY_LEAD_DAYS);
  return date.toISOString().slice(0, 10);
}

function Checkout() {
  const navigate = useNavigate();
  const { profile, user } = useAuth();
  const { lines, subtotal, shipping, total, clear } = useCart();
  const submitOrder = useServerFn(placeOrder);

  const [method, setMethod] = useState<"card" | "bank" | "cod">("card");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [placed, setPlaced] = useState<{ order_number: string } | null>(null);

  const minDate = useMemo(earliestDeliveryISO, []);

  useEffect(() => {
    if (!placed && lines.length === 0) navigate({ to: "/", replace: true });
  }, [lines.length, placed, navigate]);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    const form = new FormData(event.currentTarget);

    try {
      const order = await submitOrder({
        data: {
          items: lines.map((l) => ({ id: l.id, qty: l.qty })),
          customer_name: String(form.get("customer_name") ?? ""),
          customer_phone: String(form.get("customer_phone") ?? ""),
          delivery_address: String(form.get("delivery_address") ?? ""),
          delivery_city: String(form.get("delivery_city") ?? ""),
          delivery_postal_code: String(form.get("delivery_postal_code") ?? ""),
          delivery_date: String(form.get("delivery_date") ?? ""),
          delivery_slot: String(form.get("delivery_slot") ?? "") as (typeof DELIVERY_SLOTS)[number],
          payment_method: method,
          payment_reference: String(form.get("payment_reference") ?? "") || undefined,
          notes: String(form.get("notes") ?? "") || undefined,
        },
      });
      setPlaced({ order_number: order.order_number });
      clear();
    } catch (err) {
      setError((err as Error).message || "Could not place the order. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  if (placed) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="wrap py-24">
          <div className="mx-auto max-w-lg rounded-3xl border border-border bg-surface p-8 text-center">
            <h1 className="font-display text-2xl font-bold">Order confirmed</h1>
            <p className="mt-3 text-sm text-muted-foreground">
              Your order number is{" "}
              <span className="font-mono text-foreground">{placed.order_number}</span>. The store owner
              has been notified with your details and delivery slot. Follow every step — confirmed, packed,
              shipped, out for delivery — on your orders page.
            </p>
            <div className="mt-6 flex justify-center gap-3">
              <Link
                to="/orders"
                className="rounded-full px-5 py-2.5 text-sm font-semibold text-primary-foreground gradient-fill"
              >
                View my orders
              </Link>
              <Link
                to="/"
                className="rounded-full border border-border px-5 py-2.5 text-sm font-semibold hover:bg-surface"
              >
                Keep shopping
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="wrap py-14">
        <h1 className="font-display text-3xl font-bold tracking-tight">Checkout</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Signed in as <span className="text-foreground">{user?.email}</span>
        </p>

        <form onSubmit={handleSubmit} className="mt-8 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
          <div className="space-y-8">
            <section className="rounded-2xl border border-border bg-surface p-6">
              <h2 className="font-display text-lg font-semibold">Delivery details</h2>
              <div className="mt-4 space-y-3">
                <input
                  name="customer_name"
                  defaultValue={profile?.full_name ?? ""}
                  placeholder="Full name"
                  required
                  className={inputClass}
                />
                <input
                  name="customer_phone"
                  type="tel"
                  defaultValue={profile?.phone ?? ""}
                  placeholder="Phone number"
                  required
                  className={inputClass}
                />
                <textarea
                  name="delivery_address"
                  defaultValue={profile?.address ?? ""}
                  placeholder="Delivery address (house, street, area)"
                  required
                  rows={3}
                  className={inputClass}
                />
                <div className="grid grid-cols-2 gap-3">
                  <input
                    name="delivery_city"
                    defaultValue={profile?.city ?? ""}
                    placeholder="City"
                    required
                    className={inputClass}
                  />
                  <input
                    name="delivery_postal_code"
                    defaultValue={profile?.postal_code ?? ""}
                    placeholder="PIN / ZIP"
                    required
                    className={inputClass}
                  />
                </div>
              </div>
            </section>

            <section className="rounded-2xl border border-border bg-surface p-6">
              <h2 className="font-display text-lg font-semibold">Delivery slot</h2>
              <p className="mt-1 text-[13px] text-muted-foreground">
                Every order is dispatched after one week — the earliest date you can pick is{" "}
                {minDate}. No same-day or next-day delivery.
              </p>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <label className="text-sm">
                  <span className="text-muted-foreground">Delivery date</span>
                  <input
                    name="delivery_date"
                    type="date"
                    min={minDate}
                    defaultValue={minDate}
                    required
                    className={`${inputClass} mt-1.5`}
                  />
                </label>
                <label className="text-sm">
                  <span className="text-muted-foreground">Time window</span>
                  <select name="delivery_slot" required className={`${inputClass} mt-1.5`}>
                    {DELIVERY_SLOTS.map((slot) => (
                      <option key={slot} value={slot}>
                        {slot}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <textarea
                name="notes"
                rows={2}
                placeholder="Delivery notes (optional) — landmark, gate code, best time to call"
                className={`${inputClass} mt-3`}
              />
            </section>

            <section className="rounded-2xl border border-border bg-surface p-6">
              <h2 className="font-display text-lg font-semibold">Payment method</h2>
              <div className="mt-4 space-y-3">
                {PAYMENT_METHODS.map((option) => (
                  <label
                    key={option.id}
                    className={`flex cursor-pointer gap-3 rounded-xl border p-4 transition-colors ${
                      method === option.id
                        ? "border-brand-violet bg-surface-2"
                        : "border-border hover:bg-surface-2"
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment_method"
                      value={option.id}
                      checked={method === option.id}
                      onChange={() => setMethod(option.id)}
                      className="mt-1"
                    />
                    <span>
                      <span className="block text-sm font-semibold">{option.title}</span>
                      <span className="mt-1 block text-[13px] text-muted-foreground">
                        {option.body}
                      </span>
                    </span>
                  </label>
                ))}
              </div>
              {method === "bank" && (
                <input
                  name="payment_reference"
                  placeholder="Transfer reference / UTR number"
                  className={`${inputClass} mt-3`}
                />
              )}
            </section>
          </div>

          <aside className="h-fit rounded-2xl border border-border bg-surface p-6 lg:sticky lg:top-24">
            <h2 className="font-display text-lg font-semibold">Order summary</h2>
            <ul className="mt-4 space-y-3">
              {lines.map((line) => (
                <li key={line.id} className="flex justify-between gap-3 text-sm">
                  <span>
                    {line.qty} × {line.name}
                  </span>
                  <span className="font-mono">{formatPrice(line.price * line.qty)}</span>
                </li>
              ))}
            </ul>
            <dl className="mt-5 space-y-2 border-t border-border pt-4 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Subtotal</dt>
                <dd className="font-mono">{formatPrice(subtotal)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Shipping</dt>
                <dd className="font-mono">{shipping === 0 ? "Free" : formatPrice(shipping)}</dd>
              </div>
              <div className="flex justify-between border-t border-border pt-2 text-base font-semibold">
                <dt>Total</dt>
                <dd className="font-mono">{formatPrice(total)}</dd>
              </div>
            </dl>

            {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

            <button
              type="submit"
              disabled={busy || lines.length === 0}
              className="mt-5 w-full rounded-full py-3 text-sm font-semibold text-primary-foreground gradient-fill disabled:opacity-60"
            >
              {busy ? "Placing order…" : `Place order · ${formatPrice(total)}`}
            </button>
            <p className="mt-3 text-xs text-muted-foreground-2">
              Placing the order notifies the store owner with your name, contact, address and chosen
              delivery slot.
            </p>
          </aside>
        </form>
      </main>

      <Footer />
    </div>
  );
}
