import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";

import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({
    meta: [
      { title: "My details — EV" },
      {
        name: "description",
        content: "Update the name, phone number and delivery address saved on your EV account.",
      },
      { property: "og:title", content: "My details — EV" },
      {
        property: "og:description",
        content: "Keep your EV delivery details up to date for faster checkout.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Account,
});

const inputClass =
  "w-full rounded-xl border border-border bg-surface-2 px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground-2 focus:border-brand-violet";

function Account() {
  const { user, profile, refreshProfile } = useAuth();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!user) return;
    setBusy(true);
    setError(null);
    setMessage(null);
    const form = new FormData(event.currentTarget);

    const { error: updateError } = await supabase
      .from("profiles")
      .update({
        full_name: String(form.get("full_name") ?? "").trim(),
        phone: String(form.get("phone") ?? "").trim(),
        address: String(form.get("address") ?? "").trim(),
        city: String(form.get("city") ?? "").trim(),
        postal_code: String(form.get("postal_code") ?? "").trim(),
      })
      .eq("id", user.id);

    if (updateError) setError(updateError.message);
    else {
      await refreshProfile();
      setMessage("Your details are saved.");
    }
    setBusy(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="wrap py-14">
        <h1 className="font-display text-3xl font-bold tracking-tight">My details</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Saved to <span className="text-foreground">{user?.email}</span>
        </p>

        <form
          onSubmit={handleSubmit}
          className="mt-8 max-w-lg space-y-3 rounded-2xl border border-border bg-surface p-6"
        >
          <input
            name="full_name"
            defaultValue={profile?.full_name ?? ""}
            placeholder="Full name"
            required
            className={inputClass}
          />
          <input
            name="phone"
            type="tel"
            defaultValue={profile?.phone ?? ""}
            placeholder="Phone number"
            required
            className={inputClass}
          />
          <textarea
            name="address"
            rows={3}
            defaultValue={profile?.address ?? ""}
            placeholder="Delivery address"
            required
            className={inputClass}
          />
          <div className="grid grid-cols-2 gap-3">
            <input
              name="city"
              defaultValue={profile?.city ?? ""}
              placeholder="City"
              required
              className={inputClass}
            />
            <input
              name="postal_code"
              defaultValue={profile?.postal_code ?? ""}
              placeholder="PIN / ZIP"
              required
              className={inputClass}
            />
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}
          {message && <p className="text-sm text-brand-cyan">{message}</p>}

          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-full py-3 text-sm font-semibold text-primary-foreground gradient-fill disabled:opacity-60"
          >
            {busy ? "Saving…" : "Save details"}
          </button>
        </form>
      </main>

      <Footer />
    </div>
  );
}
