import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";

import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { formatPrice } from "@/lib/products";
import { statusLabel, TRACKING_STEPS } from "@/components/OrderTracker";
import { adminOverview, updateOrder } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin control room — EV" },
      {
        name: "description",
        content:
          "Owner-only EV dashboard: every order, payment status, customer details, delivery slot and shipment tracking in one place.",
      },
      { property: "og:title", content: "Admin control room — EV" },
      {
        property: "og:description",
        content: "Owner-only view of EV orders, payments, customers and deliveries.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AdminPage,
});

const ALL_STATUSES = [...TRACKING_STEPS.map((s) => s.key), "cancelled"] as const;
const PAYMENT_STATUSES = [
  "pending",
  "pending_on_delivery",
  "awaiting_transfer_check",
  "awaiting_card_payment",
  "paid",
  "refunded",
  "failed",
] as const;

type OrderPatch = {
  id: string;
  status?: string;
  payment_status?: string;
  carrier?: string;
  tracking_number?: string;
  eta_date?: string;
};

function AdminPage() {
  const fetchOverview = useServerFn(adminOverview);
  const saveOrder = useServerFn(updateOrder);
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);

  const { data, isLoading, error } = useQuery({
    queryKey: ["admin-overview"],
    queryFn: () => fetchOverview(),
    retry: false,
  });

  const mutation = useMutation({
    mutationFn: (input: OrderPatch) => saveOrder({ data: input }),
    onSuccess: () => {
      toast.success("Order updated");
      void queryClient.invalidateQueries({ queryKey: ["admin-overview"] });
      void queryClient.invalidateQueries({ queryKey: ["orders"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const orders = useMemo(() => {
    const rows = (data?.orders ?? []) as any[];
    const q = search.trim().toLowerCase();
    return rows.filter((o) => {
      if (filter !== "all" && o.status !== filter) return false;
      if (!q) return true;
      return [o.order_number, o.customer_name, o.customer_email, o.customer_phone, o.delivery_city]
        .filter(Boolean)
        .some((v: string) => String(v).toLowerCase().includes(q));
    });
  }, [data, filter, search]);

  const forbidden = error && /forbidden/i.test(error.message);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="wrap py-14">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground-2">
              Owner only
            </p>
            <h1 className="mt-1 font-display text-3xl font-bold tracking-tight">Admin control room</h1>
          </div>
          <Link
            to="/orders"
            className="rounded-full border border-border px-4 py-2 text-sm font-medium hover:bg-surface"
          >
            Customer view
          </Link>
        </div>

        {forbidden && (
          <div className="mt-8 rounded-2xl border border-border bg-surface p-8">
            <h2 className="font-display text-lg font-semibold">Access denied</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              This area is restricted to store administrators. If this is your store, ask for the admin
              role to be added to your account.
            </p>
          </div>
        )}

        {error && !forbidden && (
          <p className="mt-8 text-sm text-destructive">{error.message}</p>
        )}

        {isLoading && <p className="mt-8 text-sm text-muted-foreground">Loading store data…</p>}

        {data && (
          <>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
              {[
                { label: "Orders", value: String(data.stats.orderCount) },
                { label: "Order value", value: formatPrice(data.stats.revenue) },
                { label: "Collected", value: formatPrice(data.stats.collected) },
                { label: "Awaiting payment", value: String(data.stats.pendingPayment) },
                { label: "Customers", value: String(data.customers.length) },
              ].map((card) => (
                <div key={card.label} className="rounded-2xl border border-border bg-surface p-5">
                  <p className="text-xs text-muted-foreground-2">{card.label}</p>
                  <p className="mt-2 font-display text-xl font-bold">{card.value}</p>
                </div>
              ))}
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-2">
              {["all", ...ALL_STATUSES].map((key) => (
                <button
                  key={key}
                  onClick={() => setFilter(key)}
                  className={`rounded-full border px-4 py-2 text-xs font-medium capitalize transition-colors ${
                    filter === key
                      ? "border-transparent text-primary-foreground gradient-fill"
                      : "border-border text-muted-foreground hover:bg-surface"
                  }`}
                >
                  {key === "all" ? "All orders" : statusLabel(key)}
                  {key !== "all" && data.stats.byStatus[key] ? ` · ${data.stats.byStatus[key]}` : ""}
                </button>
              ))}
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search order, name, phone, city…"
                className="ml-auto w-full max-w-xs rounded-full border border-border bg-surface px-4 py-2 text-sm outline-none focus:border-ring sm:w-auto"
              />
            </div>

            <div className="mt-6 space-y-4">
              {orders.length === 0 && (
                <p className="rounded-2xl border border-border bg-surface p-8 text-center text-sm text-muted-foreground">
                  No orders match this view yet.
                </p>
              )}

              {orders.map((order) => (
                <article key={order.id} className="rounded-2xl border border-border bg-surface p-6">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="font-mono text-sm font-semibold">{order.order_number}</p>
                      <p className="mt-1 text-xs text-muted-foreground-2">
                        {new Date(order.created_at).toLocaleString("en-IN")} · {order.customer_name}
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded-full border border-border px-3 py-1 text-xs font-medium">
                        {statusLabel(order.status)}
                      </span>
                      <span className="rounded-full border border-border px-3 py-1 text-xs font-medium capitalize">
                        {order.payment_method} · {String(order.payment_status).replace(/_/g, " ")}
                      </span>
                      <span className="font-mono text-sm font-semibold">{formatPrice(order.total)}</span>
                      <button
                        onClick={() => setOpenId(openId === order.id ? null : order.id)}
                        className="rounded-full border border-border px-3 py-1 text-xs font-medium hover:bg-surface-2"
                      >
                        {openId === order.id ? "Hide" : "Manage"}
                      </button>
                    </div>
                  </div>

                  {openId === order.id && (
                    <div className="mt-5 grid gap-6 border-t border-border pt-5 lg:grid-cols-2">
                      <div className="space-y-4 text-sm">
                        <div>
                          <p className="text-xs text-muted-foreground-2">Customer</p>
                          <p className="mt-1">{order.customer_name}</p>
                          <p className="text-muted-foreground">{order.customer_email}</p>
                          <p className="text-muted-foreground">{order.customer_phone}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground-2">Deliver to</p>
                          <p className="mt-1 text-muted-foreground">
                            {order.delivery_address}, {order.delivery_city} {order.delivery_postal_code}
                          </p>
                          <p className="mt-1">
                            {order.delivery_date ?? "—"}
                            {order.delivery_slot ? ` · ${order.delivery_slot}` : ""}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground-2">Items</p>
                          <ul className="mt-1 space-y-1 text-muted-foreground">
                            {(order.items ?? []).map((item: any, i: number) => (
                              <li key={`${order.id}-i-${i}`}>
                                {item.qty} × {item.name} — {formatPrice(item.line_total ?? item.price)}
                              </li>
                            ))}
                          </ul>
                          <p className="mt-2 text-xs text-muted-foreground-2">
                            Subtotal {formatPrice(order.subtotal)} · Shipping{" "}
                            {order.shipping ? formatPrice(order.shipping) : "Free"}
                            {order.payment_reference ? ` · Ref ${order.payment_reference}` : ""}
                          </p>
                        </div>
                        {order.notes && (
                          <div>
                            <p className="text-xs text-muted-foreground-2">Customer note</p>
                            <p className="mt-1 text-muted-foreground">{order.notes}</p>
                          </div>
                        )}
                        <div>
                          <p className="text-xs text-muted-foreground-2">History</p>
                          <ul className="mt-1 space-y-1 text-xs text-muted-foreground">
                            {[...(order.order_events ?? [])]
                              .sort(
                                (a: any, b: any) =>
                                  new Date(a.created_at).getTime() - new Date(b.created_at).getTime(),
                              )
                              .map((ev: any) => (
                                <li key={ev.id}>
                                  {new Date(ev.created_at).toLocaleString("en-IN")} — {ev.message}
                                </li>
                              ))}
                          </ul>
                        </div>
                      </div>

                      <form
                        className="space-y-3 rounded-xl border border-border bg-surface-2 p-4"
                        onSubmit={(e) => {
                          e.preventDefault();
                          const form = new FormData(e.currentTarget);
                          mutation.mutate({
                            id: order.id,
                            status: String(form.get("status")) as any,
                            payment_status: String(form.get("payment_status")) as any,
                            carrier: String(form.get("carrier") ?? ""),
                            tracking_number: String(form.get("tracking_number") ?? ""),
                            ...(form.get("eta_date")
                              ? { eta_date: String(form.get("eta_date")) }
                              : {}),
                          });
                        }}
                      >
                        <p className="font-display text-sm font-semibold">Quick status</p>
                        <div className="grid grid-cols-2 gap-2">
                          {[
                            { key: "confirmed", label: "Received" },
                            { key: "packed", label: "Preparing" },
                            { key: "out_for_delivery", label: "Out for delivery" },
                            { key: "delivered", label: "Delivered" },
                          ].map((step) => (
                            <button
                              key={step.key}
                              type="button"
                              disabled={mutation.isPending || order.status === step.key}
                              onClick={() => mutation.mutate({ id: order.id, status: step.key })}
                              className={`rounded-lg border px-3 py-2 text-xs font-semibold transition-colors disabled:cursor-default ${
                                order.status === step.key
                                  ? "border-brand-violet bg-background text-foreground"
                                  : "border-border hover:bg-background"
                              }`}
                            >
                              {order.status === step.key ? `✓ ${step.label}` : step.label}
                            </button>
                          ))}
                        </div>
                        <p className="font-display text-sm font-semibold">Update this order</p>

                        <label className="block text-xs text-muted-foreground-2">
                          Delivery status
                          <select
                            name="status"
                            defaultValue={order.status}
                            className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground"
                          >
                            {ALL_STATUSES.map((s) => (
                              <option key={s} value={s}>
                                {statusLabel(s)}
                              </option>
                            ))}
                          </select>
                        </label>

                        <label className="block text-xs text-muted-foreground-2">
                          Payment status
                          <select
                            name="payment_status"
                            defaultValue={order.payment_status}
                            className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground"
                          >
                            {PAYMENT_STATUSES.map((s) => (
                              <option key={s} value={s}>
                                {s.replace(/_/g, " ")}
                              </option>
                            ))}
                          </select>
                        </label>

                        <div className="grid gap-3 sm:grid-cols-2">
                          <label className="block text-xs text-muted-foreground-2">
                            Carrier
                            <input
                              name="carrier"
                              defaultValue={order.carrier ?? ""}
                              placeholder="EV Express"
                              className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm"
                            />
                          </label>
                          <label className="block text-xs text-muted-foreground-2">
                            Tracking number
                            <input
                              name="tracking_number"
                              defaultValue={order.tracking_number ?? ""}
                              className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm"
                            />
                          </label>
                        </div>

                        <label className="block text-xs text-muted-foreground-2">
                          Delivery ETA
                          <input
                            type="date"
                            name="eta_date"
                            defaultValue={order.eta_date ?? order.delivery_date ?? ""}
                            className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm"
                          />
                        </label>

                        <button
                          type="submit"
                          disabled={mutation.isPending}
                          className="w-full rounded-full px-5 py-2.5 text-sm font-semibold text-primary-foreground gradient-fill disabled:opacity-60"
                        >
                          {mutation.isPending ? "Saving…" : "Save changes"}
                        </button>
                      </form>
                    </div>
                  )}
                </article>
              ))}
            </div>

            <h2 className="mt-14 font-display text-2xl font-bold tracking-tight">Registered customers</h2>
            <div className="mt-4 overflow-x-auto rounded-2xl border border-border bg-surface">
              <table className="w-full text-left text-sm">
                <thead className="text-xs text-muted-foreground-2">
                  <tr className="border-b border-border">
                    <th className="px-5 py-3">Name</th>
                    <th className="px-5 py-3">Phone</th>
                    <th className="px-5 py-3">Address</th>
                    <th className="px-5 py-3">Signed up</th>
                    <th className="px-5 py-3">Orders</th>
                  </tr>
                </thead>
                <tbody>
                  {(data.customers as any[]).map((c) => {
                    const count = (data.orders as any[]).filter((o) => o.user_id === c.id).length;
                    return (
                      <tr key={c.id} className="border-b border-border last:border-0">
                        <td className="px-5 py-3">{c.full_name || "—"}</td>
                        <td className="px-5 py-3 text-muted-foreground">{c.phone || "—"}</td>
                        <td className="px-5 py-3 text-muted-foreground">
                          {[c.address, c.city, c.postal_code].filter(Boolean).join(", ") || "—"}
                        </td>
                        <td className="px-5 py-3 text-muted-foreground">
                          {new Date(c.created_at).toLocaleDateString("en-IN")}
                        </td>
                        <td className="px-5 py-3">{count}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </main>

      <Footer />
    </div>
  );
}
