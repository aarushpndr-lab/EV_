import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";

import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { CartDrawer } from "@/components/CartDrawer";
import { ProductReel } from "@/components/ProductReel";
import { useCart } from "@/lib/cart";
import { CATEGORIES, PRODUCTS, formatPrice } from "@/lib/products";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "EV — Electronics store with real checkout & delivery slots" },
      {
        name: "description",
        content:
          "Shop phones, laptops, audio and smart home gear on EV. Create an account, pay your way and pick the delivery slot that suits you.",
      },
      { property: "og:title", content: "EV — Electronics" },
      {
        property: "og:description",
        content:
          "Phones, laptops, audio and smart home gear with real orders, saved accounts and scheduled delivery.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const STATS = [
  { value: "12k+", label: "Orders delivered" },
  { value: "4.8★", label: "Average rating" },
  { value: "48h", label: "Metro delivery" },
];

function Index() {
  const { add, openDrawer } = useCart();
  const [category, setCategory] = useState<string | null>(null);

  const visibleProducts = category
    ? PRODUCTS.filter((p) => p.category === category)
    : PRODUCTS;

  const selectCategory = (next: string | null) => {
    setCategory(next);
    document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
  };

  const addToCart = (id: string) => {
    add(id);
    openDrawer();
  };


  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main>
        {/* Hero */}
        <section className="relative overflow-hidden border-b border-border">
          <div className="glow-blob" aria-hidden />
          <div className="wrap grid items-center gap-12 py-20 md:grid-cols-2 md:py-28">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-border bg-surface px-3.5 py-1.5 text-xs font-medium text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-brand-cyan" /> Fresh stock every week
              </span>
              <h1 className="mt-5 font-display text-[clamp(2.4rem,6vw,4.2rem)] font-bold leading-[1.05] tracking-tight">
                Electronics that
                <br />
                <span className="gradient-text">actually arrive</span> on time.
              </h1>
              <p className="mt-5 max-w-md text-[15.5px] leading-relaxed text-muted-foreground">
                Sign in once, save your address and phone, then choose the exact day and time slot for
                delivery. Every order is confirmed by a real person — no silent checkouts.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link
                  to="/"
                  hash="products"
                  className="rounded-full px-6 py-3 text-sm font-semibold text-primary-foreground gradient-fill"
                >
                  Shop new arrivals
                </Link>
                <Link
                  to="/auth"
                  className="rounded-full border border-border px-6 py-3 text-sm font-semibold transition-colors hover:bg-surface"
                >
                  Create an account
                </Link>
              </div>
              <dl className="mt-10 flex gap-8">
                {STATS.map((stat) => (
                  <div key={stat.label}>
                    <dt className="font-display text-xl font-bold">{stat.value}</dt>
                    <dd className="text-xs text-muted-foreground-2">{stat.label}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="relative">
              <div className="charge-rule mb-6" aria-hidden />
              <ProductReel />
            </div>

          </div>
        </section>

        {/* Categories */}
        <section id="categories" className="border-b border-border py-16">
          <div className="wrap">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <h2 className="font-display text-2xl font-bold tracking-tight">Browse categories</h2>
              {category && (
                <button
                  onClick={() => selectCategory(null)}
                  className="text-sm font-medium text-brand-cyan hover:underline"
                >
                  Clear filter · show all
                </button>
              )}
            </div>
            <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              {CATEGORIES.map((name) => {
                const count = PRODUCTS.filter((p) => p.category === name).length;
                const active = category === name;
                return (
                  <button
                    key={name}
                    onClick={() => selectCategory(active ? null : name)}
                    aria-pressed={active}
                    className={`rounded-2xl border p-5 text-center text-sm font-medium transition-colors ${
                      active
                        ? "border-brand-violet bg-surface-2"
                        : "border-border bg-surface hover:border-brand-violet hover:bg-surface-2"
                    }`}
                  >
                    {name}
                    <span className="mt-1 block text-[11px] text-muted-foreground-2">
                      {count} {count === 1 ? "item" : "items"}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        {/* Products */}
        <section id="products" className="py-16">
          <div className="wrap">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <h2 className="font-display text-2xl font-bold tracking-tight">
                {category ?? "New arrivals"}
              </h2>
              <p className="text-sm text-muted-foreground">
                Free shipping on orders over {formatPrice(7500)}
              </p>
            </div>

            {visibleProducts.length === 0 && (
              <p className="mt-8 rounded-2xl border border-border bg-surface p-6 text-sm text-muted-foreground">
                Nothing in {category} yet — more EV gear is on the way.
              </p>
            )}

            <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {visibleProducts.map((product) => (
                <article
                  key={product.id}
                  className="flex flex-col overflow-hidden rounded-2xl border border-border bg-surface transition-colors hover:border-brand-violet/60"
                >
                  <div className="relative aspect-[4/3] bg-surface-2">
                    {product.image ? (
                      <img
                        src={product.image}
                        alt={product.name}
                        loading="lazy"
                        className="h-full w-full object-contain"
                      />

                    ) : (
                      <div className="charge-shimmer h-full w-full" aria-hidden />
                    )}
                    {product.badge && (
                      <span className="absolute left-3 top-3 rounded-full bg-background/80 px-2.5 py-1 text-[11px] font-semibold backdrop-blur">
                        {product.badge}
                      </span>
                    )}
                  </div>

                  <div className="flex flex-1 flex-col p-5">
                    <p className="text-[11px] uppercase tracking-wider text-muted-foreground-2">
                      {product.category}
                    </p>
                    <h3 className="mt-1 font-display text-base font-semibold">{product.name}</h3>
                    <p className="mt-1 text-[13px] text-muted-foreground">{product.desc}</p>
                    <p className="mt-2 inline-flex w-fit items-center gap-1.5 rounded-full border border-brand-violet/40 bg-surface-2 px-2.5 py-1 text-[11px] font-semibold text-brand-cyan">
                      <span className="h-1.5 w-1.5 rounded-full bg-brand-cyan" aria-hidden />
                      Coming soon
                    </p>
                    <div className="mt-4 flex items-baseline gap-2">
                      <span className="font-mono text-lg font-semibold">
                        {formatPrice(product.price)}
                      </span>
                      {product.oldPrice && (
                        <span className="font-mono text-xs text-muted-foreground-2 line-through">
                          {formatPrice(product.oldPrice)}
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => addToCart(product.id)}
                      className="mt-5 w-full rounded-full border border-border py-2.5 text-sm font-semibold transition-colors hover:bg-surface-2"
                    >
                      Add to cart
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* How it works */}
        <section className="border-t border-border bg-surface/40 py-16">
          <div className="wrap grid gap-6 md:grid-cols-3">
            {[
              {
                step: "01",
                title: "Create your account",
                body: "Name, phone, address and email — saved once, reused on every order.",
              },
              {
                step: "02",
                title: "Pay your way",
                body: "Card, bank transfer or cash on delivery. Nothing is charged silently.",
              },
              {
                step: "03",
                title: "Pick a delivery slot",
                body: "Choose the date and the time window that works for you.",
              },
            ].map((item) => (
              <div key={item.step} className="rounded-2xl border border-border bg-surface p-6">
                <span className="font-mono text-xs text-brand-cyan">{item.step}</span>
                <h3 className="mt-3 font-display text-lg font-semibold">{item.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{item.body}</p>
              </div>
            ))}
          </div>
        </section>
      </main>

      <Footer />
      <CartDrawer />
    </div>
  );
}
