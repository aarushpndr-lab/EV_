# Going live on your own web address (e.g. evstore.in)

## 1. Get a domain
Buy one in Project Settings → Domains → Buy new domain, or from any registrar (GoDaddy, Hostinger, Namecheap, Cloudflare).

## 2. Connect it
1. Project Settings → Domains → Connect Domain.
2. Add BOTH `evstore.in` and `www.evstore.in`.
3. At your registrar add the records shown there. Typically:
   - A record, name `@`, value `185.158.133.1`
   - A record, name `www`, value `185.158.133.1`
   - TXT record, name `_lovable`, value shown in the dialog
4. Remove any old A/AAAA records for `@` or `www`.
5. Wait for "Active" (minutes to 72 hours). HTTPS is added automatically.
6. Set `evstore.in` as **Primary** so the other addresses redirect to it.

## 3. Remove any platform branding
- Publish dialog → turn off the "Edit with Lovable" badge (paid plans).
- The site title, logo, favicon and page descriptions already say EV only.
- Once your domain is Primary, visitors only ever see your address.

## 4. Real order emails from your domain
Cloud → Emails → Set up email domain, using your domain (e.g. `notify.evstore.in`).
Add the NS records it shows at your registrar. After verification, order alerts
are emailed to aarushpndr@gmail.com from `orders@evstore.in`.
Until then, see every alert in the app at **/admin-inbox** (Order email inbox).

## 5. Running from VS Code / your own hosting
Product photos are in `public/products/`. Follow SETUP.md, then `npm run build`.
